﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_app
{
    public partial class Form1 : Form
    {
        string operationPerformed = "";
        bool isOperationPerformed = false;
        double result = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button_click(object sender, EventArgs e)
        {
            if(resultbox.Text=="0" || (isOperationPerformed))
                resultbox.Clear();

            isOperationPerformed = false;
            Button button = (Button)sender;
            resultbox.Text += button.Text;

        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;

            if (result != 0)
            {
                button11.PerformClick();
                operationPerformed = button.Text;
                result = Double.Parse(resultbox.Text);
                history.Text = result + " " + operationPerformed;
                isOperationPerformed = true;
            }
            else
            {
                operationPerformed = button.Text;
                result = Double.Parse(resultbox.Text);
                history.Text = result + " " + operationPerformed;
                isOperationPerformed = true;
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            resultbox.Text = "0";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            resultbox.Text="0";
            result = 0;

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (operationPerformed == "+")
            {
                resultbox.Text = (result + double.Parse(resultbox.Text)).ToString();

            }else if(operationPerformed == "-")
            {
                resultbox.Text = (result - double.Parse(resultbox.Text)).ToString();

            }
            else if(operationPerformed == "x")
            {
                resultbox.Text = (result * double.Parse(resultbox.Text)).ToString();

            }
            else
            {
                resultbox.Text = (result / double.Parse(resultbox.Text)).ToString();
            }

            result = double.Parse(resultbox.Text);
            history.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
